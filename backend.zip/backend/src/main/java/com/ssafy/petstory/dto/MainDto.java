package com.ssafy.petstory.dto;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class MainDto {
}
