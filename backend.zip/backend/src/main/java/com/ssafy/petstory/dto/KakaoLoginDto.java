package com.ssafy.petstory.dto;

import com.ssafy.petstory.domain.Board;
import lombok.Data;

@Data
public class KakaoLoginDto {
    String email;
    String name;
}
