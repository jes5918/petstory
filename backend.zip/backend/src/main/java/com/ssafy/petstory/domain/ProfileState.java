package com.ssafy.petstory.domain;

public enum ProfileState {

    // 전체 공개, 친구만 공개, 전체 비공개

    PUBLIC, ONLYFRIEND, PRIVATE,;

}
