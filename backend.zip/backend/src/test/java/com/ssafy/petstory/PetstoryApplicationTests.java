package com.ssafy.petstory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetstoryApplicationTests {

	@Test
	void contextLoads() {
	}


}
